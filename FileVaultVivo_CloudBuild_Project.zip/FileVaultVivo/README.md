# 文件管理（私人应用空间）— Android 项目

## 云端生成 APK（不需要在自己的电脑安装 Android Studio）
1. 登录 GitHub，创建一个新的 Public 或 Private repository，例如 `FileVaultVivo`。
2. 在仓库页面选择 **Add file → Upload files**，把本项目文件夹里的所有内容上传（包括隐藏的 `.github` 文件夹），提交到 `main` 分支。
3. 打开仓库顶部 **Actions**，选择 **Build Android APK** 工作流。
4. 如果没有自动运行，点击 **Run workflow → Run workflow**。
5. 等待工作流变成绿色成功状态。
6. 打开这次运行记录页面，在页面底部 **Artifacts** 下载 `FileVaultVivo-debug-apk`。
7. 解压下载的 artifact，里面的 `app-debug.apk` 就是安装包。把它传到 vivo iQOO 13，点击安装。

## 当前实现
- 文件管理器风格首页。
- 连续点击「内部存储」5 次打开密码入口。
- 首次进入设置 4–12 位数字 PIN；之后用 PIN 解锁。
- PIN 使用 PBKDF2-HMAC-SHA256 和随机盐保存，不保存明文密码。
- 私人页列出可启动的已安装应用，点击可启动。
- 私人页启用 FLAG_SECURE，降低截图/最近任务预览泄露风险。
- 不请求网络权限，不上传密码或应用列表。

## 重要限制
这是本地密码门和应用启动列表，不是系统级应用隐藏器。普通第三方应用不能保证从 vivo 桌面、系统设置或其他启动器中移除其他应用图标。真正隐藏图标需依赖 vivo 系统隐私功能、设备管理权限或替代启动器能力。本项目不会伪称已经隐藏其他应用。
首次使用请设置 PIN 并妥善保存；忘记 PIN 当前没有找回机制。卸载应用会清除本地 PIN 设置。

## 技术信息
- applicationId: `com.example.filevault`
- minSdk: 23
- targetSdk / compileSdk: 35
- Android Gradle Plugin: 8.7.3
- GitHub Actions 构建使用 JDK 17 和 Gradle 8.9
- 尚未在真实 vivo iQOO 13 上完成设备测试。
