package com.example.filevault;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.InputType;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.util.*;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(23,28,37), PANEL = Color.rgb(37,45,57);
    private static final int TEXT = Color.rgb(239,243,248), MUTED = Color.rgb(157,169,185);
    private int secretTapCount = 0;
    private long lastTap = 0;
    private LinearLayout root;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(Color.rgb(17,23,32));
        prefs = getSharedPreferences("local_settings", MODE_PRIVATE);
        showFileManager();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius * getResources().getDisplayMetrics().density);
        return d;
    }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private void pad(View v, int l, int t, int r, int b) {
        float d=getResources().getDisplayMetrics().density;
        v.setPadding((int)(l*d),(int)(t*d),(int)(r*d),(int)(b*d));
    }
    private void addRow(LinearLayout parent, View child, int height) {
        parent.addView(child, new LinearLayout.LayoutParams(-1, height < 0 ? height : (int)(height*getResources().getDisplayMetrics().density)));
    }
    private TextView tile(String icon, String title) {
        TextView t=label(icon+"\n"+title,14,TEXT,true); t.setGravity(Gravity.CENTER);
        t.setBackground(shape(PANEL,18)); pad(t,8,18,8,18); return t;
    }

    private void showFileManager() {
        root=column(); root.setBackgroundColor(BG); pad(root,20,18,20,16);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout content=column(); scroll.addView(content);
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView folder=label("▰  文件管理",18,TEXT,true); header.addView(folder,new LinearLayout.LayoutParams(0,-2,1));
        header.addView(label("⌕",28,MUTED,false)); addRow(content,header,-2);
        TextView title=label("我的文件",27,TEXT,true); pad(title,0,30,0,4); addRow(content,title,-2);
        addRow(content,label("最近文件 · 分类管理",13,MUTED,false),-2);

        TextView search=label("⌕   搜索文件或文件夹",14,MUTED,false);
        search.setBackground(shape(PANEL,16)); pad(search,16,15,16,15); pad(search,0,22,0,20); addRow(content,search,-2);

        TextView categories=label("分类",17,TEXT,true); pad(categories,0,5,0,12); addRow(content,categories,-2);
        String[][] cats={{"▧","图片"},{"▶","视频"},{"♫","音频"},{"▤","文档"},{"↓","下载"},{"▰","其他"}};
        for(int i=0;i<2;i++){
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
            for(int j=0;j<3;j++){ TextView c=tile(cats[i*3+j][0],cats[i*3+j][1]);
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1); p.setMargins(0,0,(int)(9*getResources().getDisplayMetrics().density),0); row.addView(c,p);}
            pad(row,0,0,0,9); addRow(content,row,-2);
        }
        TextView storage=label("内部存储",17,TEXT,true); pad(storage,0,22,0,12);
        storage.setOnClickListener(v -> {
            long now=System.currentTimeMillis(); if(now-lastTap>1600) secretTapCount=0;
            lastTap=now; secretTapCount++;
            if(secretTapCount>=5){ secretTapCount=0; openPinGate(); }
            else Toast.makeText(this,"内部存储",Toast.LENGTH_SHORT).show();
        });
        addRow(content,storage,-2);
        TextView usage=label("●━━━━━━━━━━━━━━━━━━━━━━  42% 已使用",13,MUTED,false);
        usage.setBackground(shape(PANEL,14)); pad(usage,14,16,14,16); addRow(content,usage,-2);
        TextView recent=label("最近使用",17,TEXT,true); pad(recent,0,24,0,12); addRow(content,recent,-2);
        String[] names={"下载","文档","图片"};
        for(String n:names){ TextView f=label("▱     "+n+"                         今天",14,MUTED,false);
            f.setBackground(shape(PANEL,12)); pad(f,14,15,14,15); pad(f,0,0,0,8); addRow(content,f,-2);}
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView foot=label("文件管理",12,MUTED,false); foot.setGravity(Gravity.CENTER); pad(foot,0,14,0,4); addRow(root,foot,-2);
        setContentView(root);
    }

    private void openPinGate() {
        boolean configured=prefs.contains("pin_hash");
        EditText input=new EditText(this); input.setSingleLine(true); input.setTextColor(TEXT);
        input.setHintTextColor(MUTED); input.setHint(configured?"输入访问密码":"设置一个4–12位数字密码");
        input.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        LinearLayout box=column(); box.setPadding(24,12,24,4);
        TextView info=label(configured?"请输入密码":"首次使用，请设置密码",16,TEXT,true);
        box.addView(info); box.addView(input);
        new AlertDialog.Builder(this).setTitle(" ").setView(box)
            .setNegativeButton("取消",(d,w)->{})
            .setPositiveButton("确定",(d,w)->{
                String pin=input.getText().toString();
                if(pin.length()<4 || pin.length()>12){ Toast.makeText(this,"密码需为4–12位数字",Toast.LENGTH_SHORT).show(); return; }
                if(!configured){ savePin(pin); Toast.makeText(this,"密码已设置",Toast.LENGTH_SHORT).show(); showVault(); }
                else if(checkPin(pin)){ showVault(); }
                else Toast.makeText(this,"无法打开此位置",Toast.LENGTH_SHORT).show();
            }).show();
        input.requestFocus();
    }

    private void savePin(String pin) {
        byte[] salt=new byte[16]; new SecureRandom().nextBytes(salt);
        prefs.edit().putString("pin_salt", android.util.Base64.encodeToString(salt, android.util.Base64.NO_WRAP))
            .putString("pin_hash", hash(pin,salt)).apply();
    }
    private boolean checkPin(String pin) {
        try {
            byte[] salt=android.util.Base64.decode(prefs.getString("pin_salt",""), android.util.Base64.NO_WRAP);
            return hash(pin,salt).equals(prefs.getString("pin_hash",""));
        } catch(Exception e){ return false; }
    }
    private String hash(String pin, byte[] salt) {
        try {
            PBEKeySpec spec=new PBEKeySpec(pin.toCharArray(),salt,150000,256);
            byte[] out=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return android.util.Base64.encodeToString(out, android.util.Base64.NO_WRAP);
        } catch(Exception e){ throw new RuntimeException(e); }
    }

    private void showVault() {
        getWindow().setFlags( android.view.WindowManager.LayoutParams.FLAG_SECURE,
                              android.view.WindowManager.LayoutParams.FLAG_SECURE);
        root=column(); root.setBackgroundColor(BG); pad(root,20,20,20,16);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=label("私人应用",23,TEXT,true); top.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView exit=label("退出",14,MUTED,false); top.addView(exit); exit.setOnClickListener(v->{getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); showFileManager();});
        addRow(root,top,-2);
        TextView subtitle=label("已通过本机密码验证",13,MUTED,false); pad(subtitle,0,7,0,20); addRow(root,subtitle,-2);
        ScrollView sc=new ScrollView(this); LinearLayout list=column(); sc.addView(list);
        PackageManager pm=getPackageManager(); List<ApplicationInfo> apps=pm.getInstalledApplications(0);
        Collections.sort(apps,(a,b)->pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString()));
        int count=0;
        for(ApplicationInfo app:apps){
            if(pm.getLaunchIntentForPackage(app.packageName)==null || app.packageName.equals(getPackageName())) continue;
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setBackground(shape(PANEL,14)); pad(row,12,12,12,12);
            ImageView icon=new ImageView(this);
            try{icon.setImageDrawable(pm.getApplicationIcon(app));}catch(Exception ignored){}
            row.addView(icon,new LinearLayout.LayoutParams((int)(42*getResources().getDisplayMetrics().density),(int)(42*getResources().getDisplayMetrics().density)));
            TextView name=label(pm.getApplicationLabel(app).toString(),15,TEXT,true); pad(name,12,0,0,0);
            row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            TextView open=label("打开",13,0xffAFC4FF,true); row.addView(open);
            row.setOnClickListener(v->{Intent intent=pm.getLaunchIntentForPackage(app.packageName); if(intent!=null) startActivity(intent);});
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2); rp.bottomMargin=(int)(8*getResources().getDisplayMetrics().density); list.addView(row,rp); count++;
        }
        if(count==0){ TextView empty=label("没有找到可启动的应用",14,MUTED,false); pad(empty,0,30,0,0); list.addView(empty); }
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        TextView note=label("此列表仅供密码保护后查看；不会从系统桌面移除应用图标。",11,MUTED,false); pad(note,0,12,0,0); addRow(root,note,-2);
        setContentView(root);
    }

    @Override public void onBackPressed() {
        if(getWindow()!=null){ getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); }
        showFileManager();
    }
}
